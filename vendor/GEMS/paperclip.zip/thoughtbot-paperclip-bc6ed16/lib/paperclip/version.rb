module Paperclip
  VERSION = "2.5.0" unless defined? Paperclip::VERSION
end
